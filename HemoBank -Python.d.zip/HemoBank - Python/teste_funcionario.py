from database.conexao import conectar

conexao = conectar()

try:
    cursor = conexao.cursor()

    # 1. Verifica quantos funcionários existem na tabela
    cursor.execute("""
        SELECT COUNT(*)
        FROM hr.employee;
    """)

    total = cursor.fetchone()[0]
    print("Total na tabela employee:", total)

    # 2. Verifica quantos não foram excluídos
    cursor.execute("""
        SELECT COUNT(*)
        FROM hr.employee
        WHERE emp_deleted_at IS NULL;
    """)

    ativos = cursor.fetchone()[0]
    print("Não excluídos:", ativos)

    # 3. Verifica o resultado da função SQL
    cursor.execute("""
        SELECT COUNT(*)
        FROM hr.fn_list_employees();
    """)

    resultado_funcao = cursor.fetchone()[0]
    print("Retornados pela função:", resultado_funcao)

finally:
    conexao.close()