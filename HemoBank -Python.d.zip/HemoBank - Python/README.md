# HemoBank API

Backend Python/FastAPI com PostgreSQL e autenticação Supabase Auth.

## Regras de cadastro

- `criar_acesso: false`: funcionário é cadastrado apenas no PostgreSQL.
- `criar_acesso: true`: cria usuário no Supabase Auth e grava o UUID no funcionário.
- Se a gravação no PostgreSQL falhar depois da criação no Auth, a API tenta excluir a conta Auth criada para evitar usuário órfão.
- Rotas de funcionários exigem autenticação e nível administrativo.
- O login só é aceito para usuário vinculado a funcionário ativo (`emp_ems_id = 0`).

## Configuração

1. Crie um ambiente virtual.
2. Instale as dependências: `pip install -r requirements.txt`.
3. Copie `.env.example` para `.env` e preencha os valores.
4. Nunca compartilhe o `.env` nem publique a `SUPABASE_SERVICE_ROLE_KEY`.
5. Execute: `uvicorn main:app --reload`.
6. Acesse `/docs` para testar a API.

## Criar o primeiro administrador

Como o cadastro de funcionários é protegido, o primeiro administrador precisa ser preparado pelo responsável pelo banco:
1. Crie o usuário no Supabase Auth.
2. Obtenha o UUID do usuário.
3. Vincule o UUID a um funcionário em `hr.employee`, preenchendo `emp_auth_id` e `emp_access_level` com um valor permitido pela constraint existente.
4. Confirme que o funcionário está ativo (`emp_ems_id = 0`).
5. Ajuste `ADMIN_ACCESS_LEVELS` para incluir exatamente o nível administrativo utilizado no banco.

Não exponha a chave `service_role` no frontend.

## Endpoints

- `POST /auth/login`: login com e-mail e senha.
- `GET /auth/me`: dados do funcionário autenticado.
- `GET /funcionarios`: lista funcionários (administrador).
- `POST /funcionarios`: cadastra funcionário (administrador).

### Exemplo de funcionário sem acesso

```json
{
  "nome": "Nome do Funcionário",
  "cpf": "52998224725",
  "cargo": "Atendente",
  "telefone": null,
  "email": "funcionario@exemplo.com",
  "data_contratacao": "2026-11-24",
  "salario": 2500,
  "status_id": 0,
  "criar_acesso": false
}
```

### Exemplo de funcionário com acesso

```json
{
  "nome": "Nome do Funcionário",
  "cpf": "52998224725",
  "cargo": "Atendente",
  "telefone": null,
  "email": "funcionario@exemplo.com",
  "data_contratacao": "2026-11-24",
  "salario": 2500,
  "status_id": 0,
  "criar_acesso": true,
  "senha": "Senha-forte-aqui",
  "nivel_acesso": "employee"
}
```

Os valores de `nivel_acesso` devem respeitar a constraint já configurada no banco.

## Observações importantes

- O código SQL de `hr.sp_register_employee()` e a estrutura da tabela `hr.employee` precisam corresponder às colunas usadas no projeto.
- O código do ZIP recebido não contém o SQL das constraints nem os valores válidos de `emp_access_level`; por isso, configure `ADMIN_ACCESS_LEVELS` conforme seu banco.
- A compensação (exclusão do usuário Auth se o INSERT falhar) é uma segunda operação HTTP. Se a própria exclusão falhar por indisponibilidade, será necessário remover o usuário órfão manualmente no Supabase Auth.
- Os testes automatizados de integração dependem das credenciais e de um projeto Supabase de teste; não foram executados aqui.

## Rotinas SQL já existentes no banco

O projeto não recria nem executa comandos `CREATE` para as rotinas. Ele apenas
chama as rotinas que já estão instaladas no PostgreSQL/Supabase:

- `CALL hr.sp_register_employee(...)` para cadastrar funcionários;
- `SELECT * FROM hr.fn_list_employees()` para listar funcionários;
- `SELECT * FROM hr.fn_get_employee_by_auth_id(...)` para localizar o funcionário autenticado;
- `SELECT * FROM hr.fn_get_employee_by_email(...)` para localizar funcionário por e-mail.

As views `reporting.vw_stock_available` e `reporting.vw_donor_last_donation`
permanecem disponíveis no banco para serem chamadas quando implementarmos os
recursos de estoque e relatórios. Nenhuma definição SQL é duplicada neste projeto.

\n## Interface web inicial\n\nA interface HTML/CSS/JavaScript fica em `static/` e é servida pelo próprio FastAPI.\n\n1. Execute `uvicorn main:app --reload`.\n2. Abra `http://127.0.0.1:8000/`.\n3. Entre com um usuário já criado no Supabase Auth e vinculado a um funcionário ativo.\n4. O painel e o cadastro/listagem de funcionários usam as rotas existentes da API.\n\nA interface não implementa estoque, doadores, agendamentos, exames ou relatórios porque essas rotas ainda não existem neste backend. O login depende de `SUPABASE_URL` e `SUPABASE_ANON_KEY`; o cadastro com criação de login também depende de `SUPABASE_SERVICE_ROLE_KEY`. Não coloque chaves do Supabase no JavaScript/frontend.\n