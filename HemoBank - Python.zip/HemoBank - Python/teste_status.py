from database.conexao import conectar

conexao = conectar()

try:
    with conexao.cursor() as cursor:
        cursor.execute("""
            SELECT ems_id, ems_name
            FROM hr.employee_status
            ORDER BY ems_id;
        """)

        status = cursor.fetchall()

        for item in status:
            print("ID:", item[0], "| Status:", item[1])

finally:
    conexao.close()