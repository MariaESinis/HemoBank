
const $ = (id) => document.getElementById(id);

let token = localStorage.getItem("hemobank_token") || "";
let funcionario = null;
let funcionarios = [];

function setMessage(id, message, success = false) {
  const el = $(id);
  el.textContent = message;
  el.classList.toggle("success", success);
}

async function api(path, options = {}) {
  const headers = { ...(options.headers || {}) };

  if (token) headers.Authorization = `Bearer ${token}`;

  if (options.body && !(options.body instanceof FormData)) {
    headers["Content-Type"] = "application/json";
  }

  const response = await fetch(path, { ...options, headers });

  let data = {};

  try {
    data = await response.json();
  } catch {}

  if (!response.ok) {
    const detalhe = data.detail || data.mensagem;

    const mensagem = typeof detalhe === "string"
      ? detalhe
      : JSON.stringify(detalhe || data);

    throw new Error(mensagem || `Erro HTTP ${response.status}`);
  }

  return data;
}

function showApp() {
  $("login-view").classList.add("hidden");
  $("app-view").classList.remove("hidden");
  $("nav").classList.remove("hidden");

  $("current-user").textContent = funcionario?.nome || "Conectado";
  $("welcome").textContent = `Olá, ${funcionario?.nome || "gestor"}!`;
  $("role").textContent = funcionario?.nivel_acesso || "Usuário";
}

function logout() {
  token = "";
  funcionario = null;

  localStorage.removeItem("hemobank_token");

  $("app-view").classList.add("hidden");
  $("nav").classList.add("hidden");
  $("login-view").classList.remove("hidden");
  $("login-password").value = "";
}

async function loadMe() {
  funcionario = await api("/auth/me");
  showApp();
  await loadEmployees();
}

function statusName(id) {
  return ({ 0: "Ativo", 1: "Afastado", 2: "Inativo" })[id] ?? String(id ?? "—");
}

function esc(value) {
  return String(value ?? "—").replace(/[&<>"']/g, c => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[c]);
}

function employeeRows(items, detailed = false) {
  return items.map(e => detailed
    ? `<tr><td>${esc(e.emp_id)}</td><td>${esc(e.emp_name)}</td><td>${esc(e.emp_cpf)}</td><td>${esc(e.emp_email)}</td><td>${esc(e.emp_position)}</td><td>${esc(e.ems_name || statusName(e.emp_ems_id))}</td><td>${esc(e.emp_access_level || "Sem acesso")}</td></tr>`
    : `<tr><td>${esc(e.emp_id)}</td><td>${esc(e.emp_name)}</td><td>${esc(e.emp_email)}</td><td>${esc(e.emp_position)}</td><td>${esc(e.ems_name || statusName(e.emp_ems_id))}</td><td>${esc(e.emp_access_level || "Não possui")}</td></tr>`
  ).join("");
}

async function loadEmployees() {
  const result = await api("/funcionarios");

  funcionarios = result.funcionarios || [];

  $("total-employees").textContent = result.total ?? funcionarios.length;
  $("dashboard-table").innerHTML = employeeRows(funcionarios.slice(0, 6));
  $("employees-table").innerHTML = employeeRows(funcionarios, true);

  $("dashboard-empty").classList.toggle("hidden", funcionarios.length > 0);
  $("employees-empty").classList.toggle("hidden", funcionarios.length > 0);

  $("api-status").textContent = "Online";
}

function switchView(view) {
  ["dashboard", "employees", "stock", "donations"].forEach(name => {
    $(`${name}-view`).classList.toggle("hidden", name !== view);
  });

  document.querySelectorAll(".nav-btn[data-view]").forEach(b => {
    b.classList.toggle("active", b.dataset.view === view);
  });

  if (view === "employees") {
    loadEmployees().catch(e => setMessage("employee-message", e.message));
  }

  if (view === "stock") {
    loadGenericView("/relatorios/estoque-disponivel", "stock");
  }

  if (view === "donations") {
    loadGenericView("/relatorios/ultima-doacao", "donations");
  }
}

function renderGenericTable(rows) {
  if (!rows.length) return "";

  const columns = Object.keys(rows[0]);

  const value = v => v === null || v === undefined
    ? "—"
    : (typeof v === "object" ? JSON.stringify(v) : String(v));

  return `<table>
    <thead>
      <tr>${columns.map(c => `<th>${esc(c)}</th>`).join("")}</tr>
    </thead>
    <tbody>
      ${rows.map(row => `<tr>${columns.map(c => `<td>${esc(value(row[c]))}</td>`).join("")}</tr>`).join("")}
    </tbody>
  </table>`;
}

async function loadGenericView(path, prefix) {
  setMessage(`${prefix}-message`, "Consultando PostgreSQL...");

  $(`${prefix}-table`).innerHTML = "";
  $(`${prefix}-empty`).classList.add("hidden");

  try {
    const result = await api(path);
    const rows = result.registros || [];

    $(`${prefix}-table`).innerHTML = renderGenericTable(rows);
    $(`${prefix}-empty`).classList.toggle("hidden", rows.length > 0);

    setMessage(
      `${prefix}-message`,
      `${result.total ?? rows.length} registro(s) encontrado(s).`,
      true
    );
  } catch (error) {
    setMessage(`${prefix}-message`, error.message);
  }
}

$("login-form").addEventListener("submit", async e => {
  e.preventDefault();

  setMessage("login-message", "Autenticando...");

  try {
    const result = await api("/auth/login", {
      method: "POST",
      body: JSON.stringify({
        email: $("login-email").value.trim(),
        senha: $("login-password").value
      })
    });

    token = result.access_token;
    localStorage.setItem("hemobank_token", token);

    funcionario = result.funcionario;

    await loadMe();

    setMessage("login-message", "");

  } catch (err) {
    token = "";
    localStorage.removeItem("hemobank_token");
    setMessage("login-message", err.message);
  }
});

$("logout").addEventListener("click", logout);

document.querySelectorAll(".nav-btn[data-view]").forEach(b => {
  b.addEventListener("click", () => switchView(b.dataset.view));
});

$("refresh-dashboard").addEventListener("click", () => {
  loadEmployees().catch(e => alert(e.message));
});

$("refresh-employees").addEventListener("click", () => {
  loadEmployees().catch(e => setMessage("employee-message", e.message));
});

$("refresh-stock").addEventListener("click", () => {
  loadGenericView("/relatorios/estoque-disponivel", "stock");
});

$("refresh-donations").addEventListener("click", () => {
  loadGenericView("/relatorios/ultima-doacao", "donations");
});

$("create-access").addEventListener("change", e => {
  $("access-fields").classList.toggle("hidden", !e.target.checked);

  $("employee-password").required = e.target.checked;
  $("employee-level").required = e.target.checked;
});

$("employee-form").addEventListener("reset", () => setTimeout(() => {
  $("access-fields").classList.add("hidden");
  $("employee-password").required = false;
  $("employee-level").required = false;
  setMessage("employee-message", "");
}, 0));

$("employee-form").addEventListener("submit", async e => {
  e.preventDefault();

  // Guarda a referência do formulário antes do await.
  const form = e.currentTarget;

  const f = new FormData(form);
  const criar = $("create-access").checked;

  const payload = {
    nome: f.get("nome").trim(),
    cpf: f.get("cpf").replace(/\D/g, ""),
    cargo: f.get("cargo").trim(),
    telefone: f.get("telefone").trim() || null,
    email: f.get("email").trim(),
    data_contratacao: f.get("data_contratacao"),
    salario: Number(f.get("salario")),
    status_id: Number(f.get("status_id")),
    criar_acesso: criar
  };

  if (criar) {
    payload.senha = $("employee-password").value;
    payload.nivel_acesso = $("employee-level").value.trim();
  }

  setMessage("employee-message", "Enviando cadastro...");

  try {
    const result = await api("/funcionarios", {
      method: "POST",
      body: JSON.stringify(payload)
    });

    setMessage(
      "employee-message",
      result.mensagem || "Funcionário cadastrado com sucesso.",
      true
    );

    // Usa a referência guardada antes da requisição.
    form.reset();

    await loadEmployees();

  } catch (err) {
    setMessage("employee-message", err.message);
  }
});

(async function init() {
  try {
    const status = await fetch("/status");

    $("api-status").textContent = status.ok
      ? "Online"
      : "Indisponível";

    if (token) await loadMe();

  } catch {
    if (token) logout();
  }
})();
